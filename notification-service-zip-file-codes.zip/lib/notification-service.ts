import { db } from "./db"

type NotificationItem = {
  id: string
  userId: string
  title: string
  message: string
  type: string
  status: string
  createdAt: string
}

export async function processNotification(notification: NotificationItem) {
  console.log(`Processing ${notification.type} notification: ${notification.id}`)

  // Simulate processing delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Simulate different notification channels
  switch (notification.type) {
    case "email":
      await sendEmail(notification)
      break
    case "sms":
      await sendSMS(notification)
      break
    case "in-app":
      await sendInAppNotification(notification)
      break
    default:
      throw new Error(`Unsupported notification type: ${notification.type}`)
  }

  // Update notification status to sent
  updateNotificationStatus(notification.id, "sent")

  return { success: true }
}

async function sendEmail(notification: NotificationItem) {
  console.log(`Sending email to user ${notification.userId}: ${notification.title}`)

  // In a real application, you would integrate with an email service like SendGrid, Mailgun, etc.
  // For demonstration, we'll simulate a successful email send

  // Randomly fail to demonstrate retry mechanism (10% chance)
  if (Math.random() < 0.1) {
    throw new Error("Failed to send email")
  }
}

async function sendSMS(notification: NotificationItem) {
  console.log(`Sending SMS to user ${notification.userId}: ${notification.title}`)

  // In a real application, you would integrate with an SMS service like Twilio, Nexmo, etc.
  // For demonstration, we'll simulate a successful SMS send

  // Randomly fail to demonstrate retry mechanism (10% chance)
  if (Math.random() < 0.1) {
    throw new Error("Failed to send SMS")
  }
}

async function sendInAppNotification(notification: NotificationItem) {
  console.log(`Sending in-app notification to user ${notification.userId}: ${notification.title}`)

  // In a real application, you might use WebSockets or a similar technology to deliver in-app notifications
  // For demonstration, we'll simulate a successful in-app notification

  // Randomly fail to demonstrate retry mechanism (10% chance)
  if (Math.random() < 0.1) {
    throw new Error("Failed to send in-app notification")
  }
}

function updateNotificationStatus(id: string, status: string) {
  const notification = db.notifications.find((n) => n.id === id)
  if (notification) {
    notification.status = status
  }
}
