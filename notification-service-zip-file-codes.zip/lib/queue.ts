// Simple queue implementation for demonstration purposes
// In a real application, you would use a proper message queue like RabbitMQ or Kafka

import { processNotification } from "./notification-service"

type QueueItem = {
  id: string
  userId: string
  title: string
  message: string
  type: string
  status: string
  createdAt: string
  retries?: number
}

const queue: QueueItem[] = []
let isProcessing = false

export function addToQueue(item: QueueItem) {
  queue.push({ ...item, retries: 0 })

  if (!isProcessing) {
    processQueue()
  }
}

async function processQueue() {
  if (queue.length === 0) {
    isProcessing = false
    return
  }

  isProcessing = true
  const item = queue.shift()

  if (!item) {
    isProcessing = false
    return
  }

  try {
    await processNotification(item)
  } catch (error) {
    console.error(`Failed to process notification ${item.id}:`, error)

    // Implement retry logic
    if ((item.retries || 0) < 3) {
      console.log(`Retrying notification ${item.id}, attempt ${(item.retries || 0) + 1}`)
      queue.push({ ...item, retries: (item.retries || 0) + 1 })
    } else {
      console.error(`Max retries reached for notification ${item.id}`)
      // Update notification status to failed
      updateNotificationStatus(item.id, "failed")
    }
  }

  // Process next item with a small delay to avoid blocking
  setTimeout(processQueue, 100)
}

function updateNotificationStatus(id: string, status: string) {
  // This would update the notification status in the database
  // For this demo, we're using the in-memory database
  const { db } = require("./db")

  const notification = db.notifications.find((n: any) => n.id === id)
  if (notification) {
    notification.status = status
  }
}

// Export for testing
export const _queue = queue
