// Simple in-memory database for demonstration purposes
// In a real application, you would use a proper database

type Notification = {
  id: string
  userId: string
  title: string
  message: string
  type: "email" | "sms" | "in-app"
  status: "sent" | "pending" | "failed"
  createdAt: string
}

// Sample data
const notifications: Notification[] = [
  {
    id: "1",
    userId: "user1",
    title: "Welcome to our platform",
    message: "Thank you for joining our platform. We're excited to have you!",
    type: "email",
    status: "sent",
    createdAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
  },
  {
    id: "2",
    userId: "user1",
    title: "New feature available",
    message: "We've just launched a new feature. Check it out!",
    type: "in-app",
    status: "sent",
    createdAt: new Date(Date.now() - 43200000).toISOString(), // 12 hours ago
  },
  {
    id: "3",
    userId: "user2",
    title: "Payment confirmation",
    message: "Your payment has been processed successfully.",
    type: "sms",
    status: "sent",
    createdAt: new Date(Date.now() - 3600000).toISOString(), // 1 hour ago
  },
]

export const db = {
  notifications,
}
