import { type NextRequest, NextResponse } from "next/server"
import { v4 as uuidv4 } from "uuid"
import { addToQueue } from "@/lib/queue"
import { db } from "@/lib/db"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, title, message, type } = body

    // Validate request
    if (!userId || !title || !message || !type) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Validate notification type
    if (!["email", "sms", "in-app"].includes(type)) {
      return NextResponse.json({ error: "Invalid notification type" }, { status: 400 })
    }

    // Create notification
    const notification = {
      id: uuidv4(),
      userId,
      title,
      message,
      type,
      status: "pending",
      createdAt: new Date().toISOString(),
    }

    // Save to database
    db.notifications.push(notification)

    // Add to processing queue
    addToQueue(notification)

    return NextResponse.json(
      {
        message: "Notification queued successfully",
        notificationId: notification.id,
      },
      { status: 201 },
    )
  } catch (error) {
    console.error("Error creating notification:", error)
    return NextResponse.json({ error: "Failed to create notification" }, { status: 500 })
  }
}
