"use client"

import type React from "react"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useState } from "react"
import { Bell, Mail, MessageSquare, RefreshCw } from "lucide-react"
import { NotificationList } from "@/components/notification-list"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-purple-100 to-indigo-100 dark:from-pink-950 dark:via-purple-950 dark:to-indigo-950">
      <div className="container mx-auto py-10 px-4">
        <header className="mb-10 text-center">
          <div className="inline-block p-3 bg-white dark:bg-gray-800 rounded-xl shadow-lg mb-4">
            <Bell className="h-10 w-10 text-purple-500" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 bg-clip-text text-transparent">
            Notification Service
          </h1>
          <p className="text-gray-600 dark:text-gray-300 mt-2 max-w-2xl mx-auto">
            A powerful backend service for managing and delivering notifications across multiple channels
          </p>
        </header>

        <Tabs defaultValue="send" className="max-w-4xl mx-auto">
          <TabsList className="grid grid-cols-2 mb-8">
            <TabsTrigger value="send" className="text-lg py-3">
              Send Notifications
            </TabsTrigger>
            <TabsTrigger value="view" className="text-lg py-3">
              View Notifications
            </TabsTrigger>
          </TabsList>

          <TabsContent value="send">
            <NotificationForm />
          </TabsContent>

          <TabsContent value="view">
            <UserNotifications />
          </TabsContent>
        </Tabs>

        <footer className="mt-20 text-center text-gray-500 dark:text-gray-400">
          <p>Notification Service - Backend Intern Project</p>
        </footer>
      </div>
    </div>
  )
}

function NotificationForm() {
  const [userId, setUserId] = useState("")
  const [title, setTitle] = useState("")
  const [message, setMessage] = useState("")
  const [type, setType] = useState("in-app")
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<null | { success: boolean; message: string }>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setResult(null)

    try {
      const response = await fetch("/api/notifications", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId,
          title,
          message,
          type,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setResult({
          success: true,
          message: "Notification sent successfully!",
        })
      } else {
        setResult({
          success: false,
          message: data.error || "Failed to send notification",
        })
      }
    } catch (error) {
      setResult({
        success: false,
        message: "An error occurred while sending the notification",
      })
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl">Send a Notification</CardTitle>
        <CardDescription>Create and send notifications to users through different channels</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label htmlFor="userId" className="text-sm font-medium">
              User ID
            </label>
            <Input
              id="userId"
              placeholder="Enter user ID"
              value={userId}
              onChange={(e) => setUserId(e.target.value)}
              required
              className="border-purple-200 focus:border-purple-500"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="title" className="text-sm font-medium">
              Notification Title
            </label>
            <Input
              id="title"
              placeholder="Enter notification title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
              className="border-purple-200 focus:border-purple-500"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="message" className="text-sm font-medium">
              Message
            </label>
            <Textarea
              id="message"
              placeholder="Enter notification message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
              className="min-h-[100px] border-purple-200 focus:border-purple-500"
            />
          </div>

          <div className="space-y-2">
            <label htmlFor="type" className="text-sm font-medium">
              Notification Type
            </label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger className="border-purple-200 focus:border-purple-500">
                <SelectValue placeholder="Select notification type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="email">
                  <div className="flex items-center">
                    <Mail className="mr-2 h-4 w-4 text-blue-500" />
                    <span>Email</span>
                  </div>
                </SelectItem>
                <SelectItem value="sms">
                  <div className="flex items-center">
                    <MessageSquare className="mr-2 h-4 w-4 text-green-500" />
                    <span>SMS</span>
                  </div>
                </SelectItem>
                <SelectItem value="in-app">
                  <div className="flex items-center">
                    <Bell className="mr-2 h-4 w-4 text-purple-500" />
                    <span>In-App</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {result && (
            <div
              className={`p-4 rounded-lg ${
                result.success
                  ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
                  : "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100"
              }`}
            >
              {result.message}
            </div>
          )}

          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 hover:from-pink-600 hover:via-purple-600 hover:to-indigo-600"
          >
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Sending...
              </>
            ) : (
              "Send Notification"
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}

function UserNotifications() {
  const [userId, setUserId] = useState("")
  const [loading, setLoading] = useState(false)
  const [notifications, setNotifications] = useState([])
  const [error, setError] = useState("")

  const fetchNotifications = async () => {
    if (!userId.trim()) {
      setError("Please enter a user ID")
      return
    }

    setLoading(true)
    setError("")

    try {
      const response = await fetch(`/api/users/${userId}/notifications`)
      const data = await response.json()

      if (response.ok) {
        setNotifications(data.notifications)
        if (data.notifications.length === 0) {
          setError("No notifications found for this user")
        }
      } else {
        setError(data.error || "Failed to fetch notifications")
      }
    } catch (error) {
      setError("An error occurred while fetching notifications")
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-2xl">User Notifications</CardTitle>
        <CardDescription>View all notifications for a specific user</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex space-x-2 mb-6">
          <Input
            placeholder="Enter user ID"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            className="border-purple-200 focus:border-purple-500"
          />
          <Button
            onClick={fetchNotifications}
            disabled={loading}
            className="bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 hover:from-pink-600 hover:via-purple-600 hover:to-indigo-600"
          >
            {loading ? (
              <>
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                Loading...
              </>
            ) : (
              "Fetch"
            )}
          </Button>
        </div>

        {error && (
          <div className="p-4 mb-6 rounded-lg bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100">{error}</div>
        )}

        {notifications.length > 0 && <NotificationList notifications={notifications} />}
      </CardContent>
    </Card>
  )
}
