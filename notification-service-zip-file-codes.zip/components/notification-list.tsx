import { Card, CardContent } from "@/components/ui/card"
import { Bell, Calendar, Mail, MessageSquare } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { formatDistanceToNow } from "date-fns"

type Notification = {
  id: string
  userId: string
  title: string
  message: string
  type: "email" | "sms" | "in-app"
  status: "sent" | "pending" | "failed"
  createdAt: string
}

export function NotificationList({ notifications }: { notifications: Notification[] }) {
  const getTypeIcon = (type: string) => {
    switch (type) {
      case "email":
        return <Mail className="h-5 w-5 text-blue-500" />
      case "sms":
        return <MessageSquare className="h-5 w-5 text-green-500" />
      case "in-app":
        return <Bell className="h-5 w-5 text-purple-500" />
      default:
        return <Bell className="h-5 w-5 text-gray-500" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "sent":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
      case "pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-100"
      case "failed":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-100"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-100"
    }
  }

  return (
    <div className="space-y-4">
      {notifications.map((notification) => (
        <Card key={notification.id} className="overflow-hidden border-l-4 border-l-purple-500">
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div className="flex items-start space-x-3">
                <div className="mt-1">{getTypeIcon(notification.type)}</div>
                <div>
                  <h3 className="font-medium text-lg">{notification.title}</h3>
                  <p className="text-gray-600 dark:text-gray-300 mt-1">{notification.message}</p>
                  <div className="flex items-center mt-2 text-sm text-gray-500 dark:text-gray-400">
                    <Calendar className="h-3.5 w-3.5 mr-1" />
                    {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                  </div>
                </div>
              </div>
              <Badge className={getStatusColor(notification.status)}>{notification.status}</Badge>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
